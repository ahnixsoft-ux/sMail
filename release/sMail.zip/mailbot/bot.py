import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import pandas as pd
import yagmail
import requests
import zipfile
import shutil
import datetime
import time
import tempfile
import hashlib
import os
import io
import re
import uuid
import json
import sys
import threading
import platform
from cryptography.fernet import Fernet

# ==========================================================
#                       Version System
# ==========================================================

__version__ = "1.0.0"  # Current app version

# Path to your license/config folder that must NOT be overwritten
OBFUSCATED_FOLDER_NAME = ".x9q2b1"
if os.name == "nt":
    license_folder = os.path.join(os.getenv("APPDATA", os.path.expanduser("~")), OBFUSCATED_FOLDER_NAME)
else:
    license_folder = os.path.join(os.path.expanduser("~/.local/share"), OBFUSCATED_FOLDER_NAME)

def safe_extract(zip_bytes, target_dir, ignore_folders=None):
    ignore_folders = ignore_folders or []
    z = zipfile.ZipFile(io.BytesIO(zip_bytes))
    for member in z.infolist():
        member_path = os.path.normpath(os.path.join(target_dir, member.filename))
        # Skip any path inside ignored folders
        if any(member_path.startswith(os.path.join(target_dir, f)) for f in ignore_folders):
            continue
        if member.is_dir():
            os.makedirs(member_path, exist_ok=True)
        else:
            os.makedirs(os.path.dirname(member_path), exist_ok=True)
            with open(member_path, "wb") as f:
                f.write(z.read(member))

def check_for_update():
    try:
        url = "https://raw.githubusercontent.com/ahnixsoft-ux/sMail/main/release/version.json"  # your hosted JSON
        data = requests.get(url, timeout=5).json()
        latest = data["latest_version"]
        download_url = data["download_url"]
        mandatory = data.get("mandatory", False)

        if latest != __version__:
            msg = f"A new version ({latest}) is available.\nDo you want to update?"
            if mandatory or messagebox.askyesno("Update Available", msg):
                download_and_update(download_url)
    except:
        pass  # fail silently if no connection

def flatten_and_copy(src_dir, dest_dir, ignore_folders=None):
    ignore_folders = ignore_folders or []
    for root, dirs, files in os.walk(src_dir):
        if any(root.startswith(os.path.join(src_dir, f)) for f in ignore_folders):
            continue
        for file in files:
            src_file = os.path.join(root, file)
            dest_file = os.path.join(dest_dir, os.path.basename(file))  # flatten
            shutil.copy2(src_file, dest_file)

def backup_current_version(target_dir):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = os.path.join(target_dir, f"backup_{timestamp}")
    os.makedirs(backup_dir, exist_ok=True)
    for item in os.listdir(target_dir):
        if item == os.path.basename(license_folder):
            continue
        item_path = os.path.join(target_dir, item)
        dest_path = os.path.join(backup_dir, item)
        if os.path.isdir(item_path):
            shutil.copytree(item_path, dest_path)
        else:
            shutil.copy2(item_path, dest_path)
    return backup_dir

def rollback_backup(backup_dir, target_dir):
    if not os.path.exists(backup_dir):
        messagebox.showerror("Rollback Failed", "Backup not found!")
        return
    for item in os.listdir(target_dir):
        if item == os.path.basename(license_folder):
            continue
        item_path = os.path.join(target_dir, item)
        if os.path.isdir(item_path):
            shutil.rmtree(item_path)
        else:
            os.remove(item_path)
    for item in os.listdir(backup_dir):
        src_path = os.path.join(backup_dir, item)
        dest_path = os.path.join(target_dir, item)
        if os.path.isdir(src_path):
            shutil.copytree(src_path, dest_path)
        else:
            shutil.copy2(src_path, dest_path)
    messagebox.showinfo("Rollback", "Previous version restored successfully.")

def download_and_update(url):
    target_dir = os.getcwd()
    try:
        # 1. Download
        resp = requests.get(url, timeout=15)
        if resp.status_code != 200:
            raise Exception(f"Download failed: HTTP {resp.status_code}")

        # 2. Extract to temp folder
        temp_dir = tempfile.mkdtemp()
        with zipfile.ZipFile(io.BytesIO(resp.content)) as z:
            z.extractall(temp_dir)

        # 3. Validate main file exists
        expected_main = os.path.join(temp_dir, "bot.py")  # adjust your main file
        if not os.path.exists(expected_main):
            for root, dirs, files in os.walk(temp_dir):
                if "bot.py" in files:
                    expected_main = os.path.join(root, "bot.py")
                    break
            else:
                raise Exception("Update ZIP missing required files!")

        # 4. Copy new files to final temp folder (flattened)
        final_temp_dir = tempfile.mkdtemp()
        flatten_and_copy(temp_dir, final_temp_dir, ignore_folders=[license_folder])

        # 5. Backup current version
        backup_dir = backup_current_version(target_dir)

        # 6. Delete old files (except license)
        for item in os.listdir(target_dir):
            if item == os.path.basename(license_folder):
                continue
            item_path = os.path.join(target_dir, item)
            if os.path.isdir(item_path):
                shutil.rmtree(item_path)
            else:
                os.remove(item_path)

        # 7. Move new files
        for item in os.listdir(final_temp_dir):
            shutil.move(os.path.join(final_temp_dir, item), target_dir)

        # 8. Cleanup temp folders
        shutil.rmtree(temp_dir)
        shutil.rmtree(final_temp_dir)

        messagebox.showinfo("Updated", "App updated successfully. Please restart.")
        sys.exit(0)

    except Exception as e:
        # On failure, rollback
        rollback_backup(backup_dir, target_dir)
        messagebox.showerror("Update Failed", f"Update failed and previous version restored.\nError: {e}")

# ==========================================================
#                     LICENSE SYSTEM
# ==========================================================
FERNET_KEY = b'n28aZs7ywQEXwPMeQiWV4Sawtpwf0fabfO1CTUlL8uY='  # Must be 32 bytes
OBFUSCATED_FOLDER_NAME = ".x9q2b1"
LICENSE_FILE_NAME = "license.dat"
BACKUP_MARKER_FILE = ".marker_backup"

# ---------------- OS-specific hidden folder ----------------
def get_hidden_folder():
    if platform.system() == "Windows":
        base_dir = os.getenv("APPDATA", os.path.expanduser("~"))
    else:
        base_dir = os.path.expanduser("~/.local/share")
    hidden_folder = os.path.join(base_dir, OBFUSCATED_FOLDER_NAME)
    os.makedirs(hidden_folder, exist_ok=True)
    return hidden_folder

def get_license_path():
    return os.path.join(get_hidden_folder(), LICENSE_FILE_NAME)

def get_backup_marker_path():
    return os.path.join(get_hidden_folder(), BACKUP_MARKER_FILE)

# ---------------- Machine ID ----------------
def get_machine_id():
    mac = uuid.getnode()
    cpu = platform.processor()
    system = platform.system()
    raw = f"{mac}-{cpu}-{system}"
    return hashlib.sha256(raw.encode()).hexdigest()

# ---------------- Signature ----------------
def generate_signature(machine_id):
    return hashlib.sha256(machine_id.encode()).hexdigest()

# ---------------- Encryption ----------------
def encrypt_data(data: str) -> str:
    f = Fernet(FERNET_KEY)
    return f.encrypt(data.encode()).decode()

def decrypt_data(enc_data: str) -> str:
    f = Fernet(FERNET_KEY)
    return f.decrypt(enc_data.encode()).decode()

# ---------------- License Check ----------------
def check_license():
    machine_id = get_machine_id()
    signature = generate_signature(machine_id)
    license_path = get_license_path()
    backup_marker_path = get_backup_marker_path()

    try:
        # First-time activation
        if not os.path.exists(license_path):
            if os.path.exists(backup_marker_path):
                messagebox.showerror("Application Error", "The app cannot start due to a license issue.")
                sys.exit()

            license_data = {
                "machine_id": machine_id,
                "signature": signature,
                "marker": encrypt_data("activated")
            }
            enc_license = encrypt_data(json.dumps(license_data))
            with open(license_path, "w") as f:
                f.write(enc_license)

            with open(backup_marker_path, "w") as f:
                f.write(encrypt_data("activated_backup"))

            return  # license generated silently

        # Load and decrypt license
        with open(license_path, "r") as f:
            enc_license = f.read()
        license_data = json.loads(decrypt_data(enc_license))

        # Validate machine and signature
        if license_data.get("machine_id") != machine_id or license_data.get("signature") != signature:
            raise Exception()

        # Validate internal marker
        if not license_data.get("marker") or decrypt_data(license_data.get("marker")) != "activated":
            raise Exception()

        # Validate backup marker
        if not os.path.exists(backup_marker_path):
            raise Exception()
        if decrypt_data(open(backup_marker_path).read()) != "activated_backup":
            raise Exception()

    except:
        # Generic client-facing message
        messagebox.showerror(
            "Application Error",
            "The app cannot start due to a license or configuration issue."
        )
        sys.exit()

# ==========================================================
#                  RESOURCE PATH (PyInstaller)
# ==========================================================
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# ==========================================================
#                  HELPER FUNCTIONS
# ==========================================================
def validate_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

def browse_file(entry_widget):
    filename = filedialog.askopenfilename(filetypes=[("CSV/Excel files","*.csv *.xlsx")])
    if filename:
        entry_widget.delete(0, tk.END)
        entry_widget.insert(0, filename)

def browse_attachments():
    files = filedialog.askopenfilenames()
    if files:
        attachments_var.set(";".join(files))

# ==========================================================
#                     PREVIEW EMAILS
# ==========================================================
def preview_emails():
    filepath = file_entry.get()
    if not os.path.exists(filepath):
        messagebox.showerror("Error", "CSV/Excel file not found!")
        return
    try:
        data = pd.read_csv(filepath) if filepath.endswith(".csv") else pd.read_excel(filepath)
    except Exception as e:
        messagebox.showerror("Error", f"File read failed:\n{e}")
        return
    if "Name" not in data.columns or "Email" not in data.columns:
        messagebox.showerror("Error", "File must contain 'Name' and 'Email' columns.")
        return
    preview_text.delete("1.0", tk.END)
    for _, row in data.head(5).iterrows():
        subject = subject_entry.get().replace("{name}", str(row["Name"]))
        body = message_text.get("1.0", tk.END).replace("{name}", str(row["Name"])).replace("{product}", str(row.get("Product","")))
        preview_text.insert(tk.END, f"To: {row['Email']}\nSubject: {subject}\n{body}\n{'-'*50}\n")

# ==========================================================
#                     EMAIL SENDING
# ==========================================================
def send_emails():
    filepath = file_entry.get()
    if not os.path.exists(filepath):
        messagebox.showerror("Error", "CSV/Excel file not found!")
        send_button.config(state="normal")
        return
    try:
        data = pd.read_csv(filepath) if filepath.endswith(".csv") else pd.read_excel(filepath)
    except Exception as e:
        messagebox.showerror("Error", f"File read failed:\n{e}")
        send_button.config(state="normal")
        return
    if "Name" not in data.columns or "Email" not in data.columns:
        messagebox.showerror("Error", "File must contain 'Name' and 'Email' columns.")
        send_button.config(state="normal")
        return
    email_address = email_entry.get().strip()
    email_password = password_entry.get().strip()
    if not email_address or not email_password:
        messagebox.showerror("Error", "Email and App Password required.")
        send_button.config(state="normal")
        return
    subject_text = subject_entry.get()
    body_text = message_text.get("1.0", tk.END)
    attachments = attachments_var.get().split(";") if attachments_var.get() else None
    try:
        yag = yagmail.SMTP(email_address, email_password)
    except Exception as e:
        messagebox.showerror("SMTP Error", f"Login failed:\n{e}")
        send_button.config(state="normal")
        return
    report = []
    total = len(data)
    progress_bar["maximum"] = total
    progress_bar["value"] = 0
    progress_label.config(text=f"Progress: 0/{total}")
    window.update_idletasks()
    for index, row in data.iterrows():
        name = str(row["Name"])
        email = str(row["Email"])
        if not validate_email(email):
            report.append({"Name": name, "Email": email, "Status": "Invalid Email"})
        else:
            try:
                personalized_subject = subject_text.replace("{name}", name)
                personalized_body = body_text.replace("{name}", name).replace("{product}", str(row.get("Product","")))
                yag.send(to=email, subject=personalized_subject, contents=personalized_body, attachments=attachments)
                report.append({"Name": name, "Email": email, "Status": "Sent"})
            except Exception as e:
                report.append({"Name": name, "Email": email, "Status": f"Failed: {e}"})
        progress_bar["value"] = index + 1
        progress_label.config(text=f"Progress: {index+1}/{total}")
        window.update_idletasks()
        time.sleep(1)
    pd.DataFrame(report).to_csv("email_report.csv", index=False)
    messagebox.showinfo("Done", "Emails processed! Report saved as email_report.csv")
    send_button.config(state="normal")

def send_emails_thread():
    send_button.config(state="disabled")
    threading.Thread(target=send_emails, daemon=True).start()

# ==========================================================
#                        HELP WINDOW
# ==========================================================
# ================= sMail Detailed Help Window =================
def show_help():
    help_text = """
sMail – User Guide

==============================
1. Email Setup
==============================
- Enter your Gmail address in the Email field.
- Enter your Gmail App Password (required; normal Gmail password will not work).
- Ensure your Gmail account allows SMTP sending.

==============================
2. CSV / Excel File
==============================
- The app reads contacts from a CSV or Excel file.
- Required columns: 
    - Name
    - Email
- Optional column:
    - Product (or any custom field)
- Placeholders in email body or subject:
    - {name} → replaced with recipient's name
    - {product} → replaced with product name if available
- Example CSV:

| Name   | Email             | Product       |
|--------|-----------------|---------------|
| Ali    | alice@example.com  | Python Book   |
| Sara   | sara@example.com | Excel Course  |
| Hassan | hassan@example.com | Binance Bot |

- Click 'Browse' to select your CSV/Excel file.
- Click 'Generate Demo CSV' to create a sample file for testing.

==============================
3. Attachments
==============================
- Optional files to attach to every email.
- Click 'Add Attachments' and select one or multiple files.
- Attachments will be sent along with the email body.

==============================
4. Subject & Message
==============================
- Enter the email subject in the Subject field.
- Enter your email message in the Message field.
- Use placeholders {name} and {product} to personalize emails for each recipient.
- Example:
    Subject: "Hello {name}, check out {product}"
    Message: "Dear {name}, we have a special offer on {product} just for you!"

==============================
5. Preview Emails
==============================
- Click 'Preview Emails' to see the first 5 personalized emails.
- Allows you to verify formatting and placeholders before sending.
- The preview shows recipient email, subject, and message.

==============================
6. Sending Emails
==============================
- Click 'Send Emails' to start sending emails.
- Progress bar shows current progress and number of emails sent.
- Report of all emails with status will be saved as 'email_report.csv'.
- Invalid emails will be flagged in the report.

==============================
7. Tips & Recommendations
==============================
- Preview emails first to avoid mistakes.
- Gmail sending limit: ~100-150 emails/day. Adjust accordingly.
- Make sure your internet connection is active.
- Avoid deleting or moving the CSV/Excel file while sending.

==============================
8. Keyboard Shortcuts
==============================
- F11 → Toggle full-screen mode.
- Esc → Exit full-screen mode.
- Scroll wheel → Scroll through the app interface.

==============================
9. Support
==============================
- For questions, suggestions, or help:
    Contact: ahnixsoft@google.com
"""
    help_window = tk.Toplevel(window)
    help_window.title("sMail User Guide")
    help_window.geometry("700x600")
    help_textbox = scrolledtext.ScrolledText(help_window, width=80, height=35)
    help_textbox.pack(padx=10, pady=10, fill="both", expand=True)
    help_textbox.insert(tk.END, help_text)
    help_textbox.config(state="disabled")
    
# ==========================================================
#                   SAMPLE CSV GENERATOR
# ==========================================================
def generate_sample_csv():
    sample_data = pd.DataFrame({
        "Name": ["Alice", "Sara", "Hassan"],
        "Email": ["alice@example.com", "sara@example.com", "hassan@example.com"],
        "Product": ["Python Book", "Excel Course", "Binance Bot"]
    })
    save_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files","*.csv")])
    if save_path:
        sample_data.to_csv(save_path, index=False)
        messagebox.showinfo("Success", f"Sample CSV created at:\n{save_path}")

# ==========================================================
#                      GUI SETUP
# ==========================================================
check_license()
check_for_update()

window = tk.Tk()
window.title("sMail")
window.geometry("750x600")
window.resizable(False,True)
window.minsize(750, 400)

# ================= Full-screen Toggle =================
def toggle_fullscreen(event=None):
    window.attributes("-fullscreen", not window.attributes("-fullscreen"))

def exit_fullscreen(event=None):
    window.attributes("-fullscreen", False)

window.bind("<F11>", toggle_fullscreen)   # Press F11 to toggle
window.bind("<Escape>", exit_fullscreen)   # Press Esc to exit full-screen

# ================= Icon =================
icon_path = resource_path("assets/bot_icon.png")
if os.path.exists(icon_path):
    window.iconphoto(True, tk.PhotoImage(file=icon_path))

# ================= Scrollable Container =================
container = tk.Frame(window)
container.pack(fill="both", expand=True)

canvas = tk.Canvas(container)
canvas.pack(side="left", fill="both", expand=True)

scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
scrollbar.pack(side="right", fill="y")

canvas.configure(yscrollcommand=scrollbar.set)
canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

scrollable_frame = tk.Frame(canvas)
canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

# Mouse wheel scrolling
def _on_mousewheel(event):
    canvas.yview_scroll(int(-1*(event.delta/120)), "units")  # Windows
canvas.bind_all("<MouseWheel>", _on_mousewheel)
canvas.bind_all("<Button-4>", lambda e: canvas.yview_scroll(-1, "units"))  # Linux scroll up
canvas.bind_all("<Button-5>", lambda e: canvas.yview_scroll(1, "units"))   # Linux scroll down

# ================= Frames =================
email_frame = tk.LabelFrame(scrollable_frame, text="Email Setup", padx=10, pady=10)
email_frame.pack(fill="x", padx=10, pady=5)

csv_frame = tk.LabelFrame(scrollable_frame, text="CSV / Excel File", padx=10, pady=10)
csv_frame.pack(fill="x", padx=10, pady=5)

attachments_frame = tk.LabelFrame(scrollable_frame, text="Attachments (Optional)", padx=10, pady=10)
attachments_frame.pack(fill="x", padx=10, pady=5)

subject_frame = tk.LabelFrame(scrollable_frame, text="Subject & Message", padx=10, pady=10)
subject_frame.pack(fill="x", padx=10, pady=5)

preview_frame = tk.LabelFrame(scrollable_frame, text="Email Preview", padx=10, pady=10)
preview_frame.pack(fill="both", expand=True, padx=10, pady=5)

buttons_frame = tk.Frame(scrollable_frame)
buttons_frame.pack(fill="x", padx=10, pady=10)

# ================= Widgets =================
# Email Inputs
tk.Label(email_frame, text="Email (Gmail SMTP)").grid(row=0, column=0, sticky="w")
email_entry = tk.Entry(email_frame, width=60)
email_entry.grid(row=0, column=1, pady=5)
tk.Label(email_frame, text="App Password").grid(row=1, column=0, sticky="w")
password_entry = tk.Entry(email_frame, width=60, show="*")
password_entry.grid(row=1, column=1, pady=5)

# CSV Inputs
file_entry = tk.Entry(csv_frame, width=50)
file_entry.grid(row=0, column=0, padx=5)
tk.Button(csv_frame, text="Browse", command=lambda: browse_file(file_entry)).grid(row=0, column=1, padx=5)
tk.Button(csv_frame, text="Generate Demo CSV", command=generate_sample_csv, bg="blue", fg="white").grid(row=0, column=2, padx=5)

# Attachments
attachments_var = tk.StringVar()
tk.Entry(attachments_frame, textvariable=attachments_var, width=50).grid(row=0, column=0, padx=5)
tk.Button(attachments_frame, text="Add Attachments", command=browse_attachments).grid(row=0, column=1, padx=5)

# Subject & Message
tk.Label(subject_frame, text="Subject").pack(anchor="w")
subject_entry = tk.Entry(subject_frame, width=70)
subject_entry.pack(pady=5)
tk.Label(subject_frame, text="Message").pack(anchor="w")
message_text = scrolledtext.ScrolledText(subject_frame, width=70, height=6)
message_text.pack(pady=5)

# Preview
preview_text = scrolledtext.ScrolledText(preview_frame, width=85, height=12)
preview_text.pack(fill="both", expand=True)

# Progress
progress_label = tk.Label(scrollable_frame, text="Progress: 0/0")
progress_label.pack()
progress_bar = ttk.Progressbar(scrollable_frame, length=600, mode="determinate")
progress_bar.pack(pady=5)

# Buttons
tk.Button(buttons_frame, text="Preview Emails", command=preview_emails).pack(side="left", padx=5)
send_button = tk.Button(buttons_frame, text="Send Emails", command=send_emails_thread, bg="green", fg="white", width=20)
send_button.pack(side="right", padx=5)

# CopyRight + Version
footer = tk.Label(
    window, 
    text=f"© 2026 AhnixSoft – sMail | Version {__version__}", 
    font=("Arial", 8), 
    fg="gray"
)
footer.pack(side="bottom", pady=5)

# Menu
menu_bar = tk.Menu(window)
help_menu = tk.Menu(menu_bar, tearoff=0)
help_menu.add_command(label="User Guide", command=show_help)
menu_bar.add_cascade(label="Help", menu=help_menu)
window.config(menu=menu_bar)

window.mainloop()